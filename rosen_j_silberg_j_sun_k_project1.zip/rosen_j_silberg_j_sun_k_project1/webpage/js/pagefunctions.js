// JavaScript Document

$('#introModal').modal()

$(function() {
    console.log( "The page has loaded, pagefunctions.js running" );
});